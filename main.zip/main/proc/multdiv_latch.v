module multdiv_latch (
    in_a, in_b, multdiv_a, multdiv_b, ctrl_multdiv, dx_ir, multdiv_ir, result_RDY, multdiv_stall, clk
);

    input [31:0] in_a, in_b, dx_ir;
    input result_RDY, ctrl_multdiv;
    input clk;
    output [31:0] multdiv_a, multdiv_b, multdiv_ir; 
    output multdiv_stall;

    single_reg multdiv_a_latch(.data_writeReg(in_a), .data_readReg(multdiv_a), .write_to(ctrl_multdiv), .ctrl_reset(1'b0), .clk(clk));
    single_reg multdiv_b_latch(.data_writeReg(in_b), .data_readReg(multdiv_b), .write_to(ctrl_multdiv), .ctrl_reset(1'b0), .clk(clk));
    single_reg multdiv_ir_latch(.data_writeReg(dx_ir), .data_readReg(multdiv_ir), .write_to(ctrl_multdiv), .ctrl_reset(1'b0), .clk(clk));

    dffe_ref stall_signal(.q(multdiv_stall), .d(1'b1), .clk(clk), .en(ctrl_multdiv), .clr(result_RDY)); 

endmodule